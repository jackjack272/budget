@section('title','testing area')
@include('partials.header')



@include('partials.footer')