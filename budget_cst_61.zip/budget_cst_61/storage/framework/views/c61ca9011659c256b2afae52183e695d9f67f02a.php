<!DOCTYPE html>
<html>

<head>
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <link rel="icon" type="image/x-icon" href="<?php echo e(asset('img/logo.jpg')); ?>">
    <link rel='stylesheet' href="<?php echo e(asset('css/customOutSide.css')); ?>">
    <link rel='stylesheet' href="<?php echo e(asset('css/customInside.css')); ?>">
    <link rel='stylesheet' href="<?php echo e(asset('css/skeleton.css')); ?>">
    <script src='<?php echo e(asset("JS/debts.js")); ?>'></script>
</head>

<body >
    <header>
        <div class='black_line'> &nbsp; <br>&nbsp;<br>&nbsp; </div>
        
        <div>
            <img class="logo" src="<?php echo e(asset('img/logo.jpg')); ?>" alt="image of logo">
        </div>
        
        <div class='centerMe'>
            <h5>Know what you want and be bold in it's pursuit.</h5>
        </div>
    </header>

    <?php echo $__env->make('partials.navInside', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <h3 class="centerMe"><?php echo $__env->yieldContent('sub_title'); ?></h3>

    
<?php /**PATH C:\Users\crist\OneDrive\Desktop\project\budget\resources\views/partials/header.blade.php ENDPATH**/ ?>