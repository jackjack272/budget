<?php $__env->startSection('title',$viewData['title']); ?>
<?php $__env->startSection('sub_title',$viewData['sub_title']); ?>
<?php echo $__env->make('partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<h4 class="moveCenter">Make an admin form</h4>
<br>
    <div class="moveCenter" name="makeAdmin">
        <form  action="<?php echo e(route('admin.add')); ?>" method="post" >

            <?php echo csrf_field(); ?>
            <label for="name">Give Them a Name </label>
            <input name="name" type="text" placeholder="bob"><br>

            <label for="name">email</label>
            <input name="email" type="email" placeholder="bob@mail.com"><br>
            
            <label for="name">Pain text password</label>
            <input name="password" type="text" placeholder="bob123"><br>

            <input type="submit" value="submit">
        </form>
    </div>
</div>

<div >
<label class="offEdge" for="all users">All users</label>
<table class="offEdge"  name="user">
    <thead>
        <tr>
            <td>name</td>
            <td>email</td>
            <td>is Admin</td>
            <td>is timed out</td>
            <td>time out expies this month</td>
           
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $viewData['users']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($user->name); ?></td>
                <td><?php echo e($user->email); ?></td>
                <td><?php echo e($user->is_admin); ?></td>
                

                <td><?php echo e($user->is_timed_out); ?></td>
                <?php if($user->time_out_expire !=0): ?>
                    <td><?php echo e($user->time_out_expire); ?>th </td>
                
                <?php else: ?>
                    <td><?php echo e($user->time_out_expire); ?></td>
                <?php endif; ?>

            </tr>
            <tr>
                <?php if($user->is_admin==true): ?>
                <td>
                    <a href="<?php echo e(route('admin.takeAdmin',['id'=>$user->id])); ?>">
                        <button>
                            take admin
                        </button>
                </td>
                <?php else: ?>

                <td>
                    <a href="<?php echo e(route('admin.giveAdmin', ['id'=>$user->id ])); ?>">
                        <button>
                            give admin
                        </button>
                    </a>
                </td>
                <?php endif; ?>

                <td>
                    <a href="<?php echo e(route('admin.time_out',['id'=>$user->id])); ?>">
                        <button>
                            give 3day time out
                        </button>
                    </a>                    
                </td>

                <td>
                    <a href="<?php echo e(route('admin.remove_time_out' ,['id'=>$user->id])); ?>">
                        <button>
                            lift ban
                        </button>
                    </a>                    
                </td>

                <td>
                    <a href="<?php echo e(route('admin.delete', ['id'=> $user->id])); ?>">
                        <button>
                            delete
                        </button>
                    </a>
                </td>
            </tr>
            <tr><td> </td></tr>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>



<div>
    <br>
    <br>
    <br>
</div>


<?php echo $__env->make('partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\crist\OneDrive\Desktop\project\budget\resources\views/admin/allUsers.blade.php ENDPATH**/ ?>