<?php $__env->startSection('title',$viewData['title']); ?>
<?php $__env->startSection('sub_title',$viewData['sub_title']); ?>
<?php echo $__env->make('partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="centerMe offEdge">
    <?php echo e($viewData['content']); ?>

</div>

<br>
<br>
<br>


    

</form>


<?php echo $__env->make('partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\crist\OneDrive\Desktop\project\budget\resources\views/API/showAPI.blade.php ENDPATH**/ ?>