

<?php $__env->startSection("title",$viewData['title']); ?>

<?php $__env->startSection('sub_title',$viewData['sub_title']); ?>
<?php echo $__env->make('partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<hr>
<br>
<br>
<br>

<form class="offEdge" method="post" action="<?php echo e(route('budget.update',['id'=>$viewData['bud']->id ])); ?>"> <!-- // i am the budget ID -->
    <?php echo csrf_field(); ?>
<table>
    <thead>
        <tr>
            <td>Who is this budget For?</td>
            <td>What's your expected expence for the month?</td>
            <td>What's your monthly earning for the month?</td>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>
                <label name="for_who"></label>
                <input type="text" maxlength="30" name="for_who" value="<?php echo e($viewData['bud']->for_who); ?>" >
            </td>

            <td>
                <label name="for_who"></label>
                <input type="number" maxlength="30" name="expected_exp" value="<?php echo e($viewData['bud']->total_inflow); ?>" >
            </td>

            <td>
                <label name="for_who"></label>
                <input type="number" maxlength="30" name="expected_inc" value="<?php echo e($viewData['bud']->total_outflow); ?>">
            </td>
        </tr>
        <tr>
            <td>
                <input type="submit" value="submit">
            </td>
        </tr>

    </tbody>
</table>
</form>


<?php echo $__env->make('partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\crist\OneDrive\Desktop\project\budget\resources\views/budget/updateForm.blade.php ENDPATH**/ ?>