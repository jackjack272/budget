<nav class='show '>
    <table>
        <tr>
            <td>budgets</td>
            <td>API</td>
            
            <?php if(auth()->guard()->check()): ?>
            <td>admin pannel</td>
            <?php endif; ?>
        </tr>

    </table>


</nav><?php /**PATH C:\Users\crist\OneDrive\Desktop\project\budget\resources\views/partials/nav.blade.php ENDPATH**/ ?>