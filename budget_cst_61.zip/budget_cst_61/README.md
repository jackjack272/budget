        Getting it up and running. 

Unzip and move to desktop
Open command prompt. Type CD  place the folders URL link,  click enter. 

Enter the following commands
    Composer install
    npm install
    Npm run build 
    Open xampp and start mySQL 

    Php artisan migrate ( yes )
    
    Php artisan db:seed
    Php artisan serve

Login with administrative account or create your own 
    Admin Credentials: admin@money.com  password: money
    The admin account will have data already inside. (seeded inside)


A back up of the database will be found inside sql folder.
im not sure if it will conflict with the seed so im choosing to not include it in
    the gettting up and running instructions. 

.\budget_db.sql | mysql -u root -p budget_cst_61 <budget_db.sql


This app was developed on a vertical screen layout so for best user experience 
    use a vertical window. 

