            problem statment

Too many people are running around over leveredged by a life style that is costing them more then the money that its bring in. 
    My moms a nurse that works like crazy her normal 13shift of 12 hours consequtively before calling in a sick day.

Thus i understand the power that money can have over a person and how it can torment them. 
A good chunk of the population lives with debt and little savings, so what happens if you cant work?
    Are you going to live with friends/ famility or the street? Thus savings are essental to having some breathing space during hard times. 

Without budgeting all you know is that you need money, there is not enought money and the only want to get more money is by working more. 
Budgeting is ensuring that your water pale is not loosing water, if it is where is it loosing from? 

I need to make an easy to use application that allows the user to address parts of their lives that are costing them the most. 
    If your wants are costing you an extra 20 hours worth of work are they really worth it? Do you need that latest and gratest x?


            Business case 

There are millions of people that are struggeling financially and the only way to get out of the rut is being responsible. 
    What're the essentals? what can i go without? how do i get rid of this debt? 
    This financial modesty is only necessary for a year or two then one can afford to introduce some fun money. There is only so much hill. 

If i can help people budget by making a colorful drag and drop app that is linked to their bank so they have something intuative on their phone
    im confident at least 3000 people would be willing to pay $4/ month for the service 
    This is the reason im in school. 
    This is my lifes goal. 

            Goal statment 
            The target of the process measurement? is to make the "out of pocket" part of the budget negative. 
                The target is to make the user have more income then expenses. 


            Time line 
            - refer to the TimeLine-cst-61


            Scope:
This project is a pilot demonstrating the newly aquired skills with the theme of budget. 
    IN Scope 
        - create budget for a person
        - create categories for that person 
        - create expense/ income items for that person. 
    
    Out of scope
        - debt reduction strategy 
        - bank integration
        - drag drop features 
        - etc

            Team?
    I am the team.
    I need to be responsible for my grades thus I choose to eliminate other factors.
        If I fail or thrive by my own hands and mind. 